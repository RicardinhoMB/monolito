<?php

namespace App\Http\Controllers;

use App\Models\alunos;
use App\Http\Requests\StorealunosRequest;
use App\Http\Requests\UpdatealunosRequest;

class AlunosController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorealunosRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(alunos $alunos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(alunos $alunos)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatealunosRequest $request, alunos $alunos)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(alunos $alunos)
    {
        //
    }
}
